#!/bin/bash

if [[ "$1" == "help" ]]; then
	echo "Uso: backup_full.sh ORIGEN DESTINO"
	echo "Ejemplo: backup_full.sh /var/log /backup_dir"
	exit 0
fi


ORIGEN="$1"
DESTINO="$2"


#VALIDAR QUE ORIGEN EXISTA
if [[ ! -d "$ORIGEN" ]]; then
	echo "Error: el directorio de origen no existe"
	exit 1
fi

#validar que destino exista
if [[ ! -d "$DESTINO" ]]; then
	echo "Error: el directorio de destino no existe"
	exit 1
fi

FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"


if tar -czf "$DESTINO/$ARCHIVO" "$ORIGEN"; then
	echo "Backup hecho correctamente"
else
	echo "Error al crear el backup"
	exit 1
fi

echo "Backup creado correctamente en: $DESTINO/$ARCHIVO"


