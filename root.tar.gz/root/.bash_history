history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostname
vi /etc/hostname
hostname
vi /etc/hostname
reboot
hostname
vi /etc/network/interfaces
reboot
apt-cache search SO
apt list
apt update 
cat /etc/debian_version
apt update
apt upgrade 
cat /etc/debian_version
apt update
apt upgrade
cat /etc/debian_version
apt full-upgrade
vi /etc/network/apt
vi /etc/apt
vi /etc/apt/sources.list
systemctl apt
systemctl restar apt
systemctl restart apt
apt update
ip a
clear
systemctl restart networking
vi /etc/network/interfaces
systemctl restart networking
ip a
apt update
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
apt update
systemctl restart networking
reboot
vi /etc/apt/sources.list
ping 8.8.8.8
ping 10.128.3.4
apt update
apt upgrade
vi /etc/apt/sources.list
vi /etc/network/interfaces
systemctl restart networking
poweroff
cd /root/.ssh
cd id_rsa.txt
nano /etc/ssh/sshd_config
vi /etc/ssh/sshd_config
ls
pwd
cat id_rsa.pub > authorized_keys
ip a
ip add show
vi /etc/network/interfaces
systemctl restart
systemctl reboot
ip a
vi /etc/network/interfaces
systemctl reboot
ip a
vi /etc/ssh/sshd_config
systemctl restart sshd
apt install -y apache2 php libapache2-mod-php
systemctl status apache2
systemctl status apache2
cp /root/index.php /var/www/html/
ls
dir
cd /root
ls
cd index.php
tar -xvzf Material_Adicional_TPVMCA.tar.gz
ls
ls -lah
cp /root/index.php /var/www/html/
cp /root/Material_Adicional_TPVMCA/index.php /var/www/html/
cp /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
ls-l
ls -l /dev/sd
lsblk
shutdown 
shutdown now
fdisk /dev/sdc
fdisk /dev/sdc
fdisk /dev/sdc
fdisk /dev/sdc
fdisk -l
lsblk
fdisk /dev/sdc3
fdisk /dev/sdc3
shutdown now
poweroff
fdisk -l
fdisk /dev/sdc
fdisk -l
mkfs .ext4 /dev/sdc1
mkfs .ext2 /dev/sdc1
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
mkdir /www_dir
mkdir /backup_dir


df -h
nano /etc/fstab
 /etc/fstab
/etc/fstab
vi /etc/fstab
vi /etc/fstab
mount -a
cp /root/index.php /www_dir/
pwd
cd /Material_Adixc+
cd /Material_Adicional
ls
cp /root/Material_Adicional_TPVMCA/index.php /www_dir/
cp /root/Material_Adicional_TPVMCA/logo.png /www_dir/
ls /ww_dir
ls /www_dir
vi /etc/apache2/sites-available/000-default.conf
apt-get install mariadb-server -y
systemctl status mariadb
mysql
ls /root
cd Material_Adicional_TPVMCA
LS
ls
apt list
cd .. 
mysql < /root/Material_Adicional_TPVMCA/db.sql
mysql
cat /proc/partitions
cat /proc/partitions > /opt/partitions
cat /opt/partitions
mkdir -p /opt/scripts
vi /opt/scripts/backup_full.sh
chmod +x /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh /var/log
vi /opt/scripts/backup_full.sh
chmod +x /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh /var/log
/opt/scripts/backup_full.sh /var/log /backup_dir
vi /opt/scripts/backup_full.sh
chmod +x /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh /var/log /backup_dir
vi /opt/scripts/backup_full.sh
chmod +x /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh /var/log /backup_dir
vi /opt/scripts/backup_full.sh
vi /opt/scripts/backup_full.sh
tar --version
/opt/scripts/backup_full.sh /var/log /backup_dir
vi /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh /var/log /backup_dir
vi /opt/scripts/backup_full.sh
poweroff
cd .ssh
ls
cat id_rsa.pub
cat authorized_keys 
exit
cd .ssh
dir
cat clave_publica.pub > authorized_keys 
cat authorized_keys 
exit
cd .ssh
ls
del id_rsa.pub
del "id_rsa.pub"
exit
